/*
 * Johannes Joujo 4.1 Sub-task 1: Display texts *
 */
// The libraries
#include "C12832.h"
#include "mbed.h"
#include "LM75B.h"
// The pins.
C12832 lcd(p5, p7, p6, p8, p11);
LM75B tmp(p28, p27);

int main()
{
    // Initialize temp to 0.
    float temp = 0;

    while (1)
    {
        // Clears the screen
        lcd.cls();
        // Finds the position of the first pixel that will be printed.
        lcd.locate(25, 10);
        // Reads the temperature from the sensor
        temp = tmp.read();
        // Prints Temp with the temperature value.
        lcd.printf("Temp = %0.2f\n\r", temp);
        // Wait one second.
        wait(1);
    }
}
